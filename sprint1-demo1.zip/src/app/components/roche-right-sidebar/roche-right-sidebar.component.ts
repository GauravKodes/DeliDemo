import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roche-right-sidebar',
  templateUrl: './roche-right-sidebar.component.html',
  styleUrls: ['./roche-right-sidebar.component.css']
})
export class RocheRightSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
