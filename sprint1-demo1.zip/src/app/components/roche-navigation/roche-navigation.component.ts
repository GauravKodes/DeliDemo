import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roche-navigation',
  templateUrl: './roche-navigation.component.html',
  styleUrls: ['./roche-navigation.component.css']
})
export class RocheNavigationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
