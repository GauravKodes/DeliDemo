import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roche-left-sidebar',
  templateUrl: './roche-left-sidebar.component.html',
  styleUrls: ['./roche-left-sidebar.component.css']
})
export class RocheLeftSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
